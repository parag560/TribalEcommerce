import React from "react";
import styled from "styled-components";
import { Link } from 'react-router-dom';

const CardWrapper = styled.div`
width: 300px;
height: 500px;

//text-align: center;

`;
const ImgWrapper = styled.div`
width: 100%;
height: 70%;
img{
  width: 100%;
  height: 100%;
}
`;
const TitleWrapper = styled.div`

`;
const CateWrapper = styled.div`
padding-left: 10px;
`;
const DetailWrapper = styled.div`
padding-left:10px;
font-weight: 600;
`;
function Cards(props) {
  return (
    <div>
      <Link style={{ textDecoration: "none" ,color:"black" }} to={`/product/${props.id}`}>
      
      <CardWrapper>
        <ImgWrapper>
          <img
            src={props.img}
            alt=""
          />
        </ImgWrapper>
        <TitleWrapper>
          
          <DetailWrapper>
            <p>{props.title}</p>
            <p><span>&#x20B9;</span> {props.price}</p>
          </DetailWrapper>
        </TitleWrapper>
      </CardWrapper>
      </Link>
    </div>
  );
}

export default Cards;
