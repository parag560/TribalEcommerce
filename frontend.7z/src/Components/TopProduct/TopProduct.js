import React, { useEffect, useState } from "react";
import Carousel from "react-elastic-carousel";
import Cards from "./Card";
import styled from "styled-components";
import { useSelector } from "react-redux";
import { mlrequest, userRequest } from "../../publicrequest";
const Title = styled.h3`
  margin-left: 150px;
`;
function TopProduct() {
  const [data, setData] = useState();
  const [order, setOrder] = useState();
  const [highestrated, sethighestrated] = useState();
  const { currentUser } = useSelector((state) => state.user);
  const [reco, setreco] = useState([]);
  const [TopRated, setTopRated] = useState([]);
  //const cid = currentUser._id;
  // console.log(order);
  console.log(reco);
  console.log(TopRated);
  console.log(highestrated);

  useEffect(() => {
    const fetchdata = async (data) => {
      console.log(data[0].products[0].productId);
      const res = await mlrequest.get(
        `/prods/${data[0].products[0].productId}`
      );
      console.log(res.data);
      setData(res.data);
      fetchhighestrated(res.data);
      fetchrecommended(res.data);
      fetchTopRatedProducts(res.data);
    };
    const fetchOrders = async () => {
      const ord = await userRequest.get(`/cart/getorder/${currentUser._id}`);
      setOrder(ord.data);
      if(ord.data){
        fetchdata(ord.data);
      }
      else{
        fetchdatanotloggged()
      }
     
    };
    const fetchhighestrated = async (data) => {
      const hres = await userRequest.get(
        `/products/productbyid/${data.HighestRatedProduct}`
      );
      console.log(hres.data);
      sethighestrated(hres.data);
    };
    const fetchrecommended = async (data) => {
      const temp = [];
      let i;
      for (i = 0; i < 3; i++) {
        const res = await userRequest.get(
          `/products/productbyid/${data.RecommendedProducts[i]}`
        );
        temp.push(res.data);
      }
      setreco(temp);
    };
    const fetchTopRatedProducts = async (data) => {
      const temp = [];
      let i;
      for (i = 0; i < 3; i++) {
        const res = await userRequest.get(
          `/products/productbyid/${data.TopRatedProducts[i]}`
        );
        temp.push(res.data);
      }
      setTopRated(temp);
    };
    const fetchdatanotloggged = async () => {
      const res = await mlrequest.get(`/prods/628a32720112dbfb244a9815`);
      setData(res.data);
      fetchhighestrated(res.data);
      fetchrecommended(res.data);
      fetchTopRatedProducts(res.data);
    };
    if (currentUser) {
      fetchOrders();
    } else {
      fetchdatanotloggged();
    }
  }, []);
  return (
    <div>
      <div>
        <div>
          <Title>Top Rated roducts</Title>
        </div>

        <div style={{ marginLeft: "0px" }}>
          <Carousel
            itemsToShow={3}
            itemsToScroll={3}
            enableAutoPlay={true}
            pagination={false}
            autoPlaySpeed={10000}
            easing={"ease"}
          >
            {TopRated.map((item) => {
              return (
                <Cards
                  img={`http://localhost:5000/uploads/${item.title}.png`}
                  title={item.title}
                  price={item.price}
                  id={item._id}
                />
              );
            })}
          </Carousel>
        </div>
      </div>
      {currentUser && (
        <div>
          <div>
            <Title>Recommended Products</Title>
          </div>
          <div style={{ marginLeft: "0px" }}>
            <Carousel
              itemsToShow={3}
              itemsToScroll={3}
              enableAutoPlay={true}
              pagination={false}
              autoPlaySpeed={10000}
              easing={"ease"}
            >
              {reco.map((item) => {
                return (
                  <Cards
                    img={`http://localhost:5000/uploads/${item.title}.png`}
                    title={item.title}
                    price={item.price}
                    id={item._id}
                  />
                );
              })}
            </Carousel>
          </div>
        </div>
      )}
    </div>
  );
}

export default TopProduct;
