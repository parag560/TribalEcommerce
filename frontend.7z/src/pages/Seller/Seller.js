import React from 'react'
import Navbar from "../../Components/Admin Comp/Navbar/Navbar"
import DemoProductList from '../../Components/Admin Comp/ProductList/DemoProductList'

function Seller() {
  return (
    <div>
      <Navbar/>
     <DemoProductList/>
      
    </div>
  )
}

export default Seller